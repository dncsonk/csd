from pymongo import MongoClient

# Connection to the MongDB Collection
url = "mongodb+srv://pytech:admin@csd.j0wjc.mongodb.net/pytech?retryWrites=true&w=majority"
client = MongoClient(url)
db = client["pytech"]
student_collection = db["students"]

# find() method to display the results


def find():
    docs = student_collection.find({})
    print("-- DISPLAYING STUDENTS DOCUMENTS FROM find() QUERY --")
    for doc in docs:
        print(
            f"Student ID: {doc['Student ID']}\nFirst Name: {doc['First Name']}\nLast Name: {doc['Last Name']}\n")


# Declare one student with student_id 1010
student = {"Student ID": "1010", "First Name": "John", "Last Name": "Doe"}

# insert method to insert one student


def insert():
    print("-- INSERT STATEMENTS --")

    student_id = student_collection.insert_one(student).inserted_id
    print(
        f"Inserted student record {student['First Name']} {student['Last Name']} into the students collection with document_id {student_id}")

# find_one method to display student (student_id = 1010)


def find_one():
    print("-- DISPLAYING STUDENT TEST DOC --")
    student = student_collection.find_one({"Student ID": "1010"})
    print(
        f"Student ID: {student['Student ID']}\nFirst Name: {student['First Name']}\nLast Name: {student['Last Name']}\n")

# delete_one() method to delete student (student_id = 1010)


def delete_one():
    student = student_collection.delete_one({"Student ID": "1010"})


# Call the above methods
find()
insert()
find_one()
delete_one()
find()
print("End of program, press any key to exit...")
