


import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
database = "mydatabase"
)

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM team")


myresult = mycursor.fetchall()


print('display team records')
for x in myresult:
  print(x)


mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM player")


myresult = mycursor.fetchall()


print('display player records')
for x in myresult:
  print(x)

